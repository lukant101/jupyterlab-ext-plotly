"use strict";
(self["webpackChunkplotly_extension"] = self["webpackChunkplotly_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Initialization data for the plotly-extension extension.
 */
const plugin = {
    id: 'plotly-extension:plugin',
    description: 'Take home test from Plotly',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette],
    activate: (app, palette) => {
        console.log('JupyterLab extension plotly-extension is activated!');
        console.log('ICommandPalette:', palette);
        const newWidget = () => {
            const content = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget();
            const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({ content });
            widget.id = 'plotly-extension';
            widget.title.label = 'Plotly Dialog';
            widget.title.closable = true;
            const dialog = document.createElement('dialog');
            // const openAttr = document.createAttribute('open')
            dialog.open = true;
            dialog.innerText = 'Hey dsfdsf  sfdsd';
            dialog.style.margin = 'auto';
            dialog.style.marginTop = '200px';
            dialog.style.height = '100px';
            const input = document.createElement('input');
            input.type = 'text';
            dialog.appendChild(input);
            content.node.appendChild(dialog);
            return widget;
        };
        let widget = newWidget();
        const command = 'plotly-extension:open-dialog';
        app.commands.addCommand(command, {
            label: 'Plotly Dialog',
            execute: () => {
                // Regenerate the widget if disposed
                if (widget.isDisposed) {
                    widget = newWidget();
                }
                if (!widget.isAttached) {
                    // Attach the widget to the main work area if it's not there
                    app.shell.add(widget, 'main');
                }
                // Activate the widget
                app.shell.activateById(widget.id);
            }
        });
        // Add the command to the palette.
        palette.addItem({ command, category: 'Custom Plotly' });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.82e5edce681855339fcc.js.map